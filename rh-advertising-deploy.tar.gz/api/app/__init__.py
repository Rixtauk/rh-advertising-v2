"""RH Education Ads API - FastAPI backend for ad copy generation and landing page optimization."""

__version__ = "0.1.0"
